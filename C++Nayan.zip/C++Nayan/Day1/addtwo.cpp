#include<iostream>
using namespace std;
int main()
{
    int a=10,b=20;
    cout<<"Additon of two number is"<<a+b;
    cout<<endl;
}