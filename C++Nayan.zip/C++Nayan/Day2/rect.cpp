#include<iostream>
using namespace std;
int main()
{
    int l,b, aor;
    cout<<"enter the length\n";
    cin>>l;
    cout<<"enter the breadth\n";
    cin>>b;
    aor=l*b;
    cout<<"area of rectangle is"<<"\t"<<aor<<endl;
    return 0;



}