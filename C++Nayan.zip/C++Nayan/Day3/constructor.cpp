#include<iostream>
using namespace std;
class Complex
{
    int a,b;
    public:
    Complex()
    {
        int a=10;
        int b=20;
        cout<<a<<b<<endl;
    }
};
int main()
{

    Complex c1;
}