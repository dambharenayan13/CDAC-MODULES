#include<iostream>
using namespace std;
#include<string.h>
int main(){
    char str[50]="Hello  World";
    char str1[]="Hello World";
    // int len=strlen(str);
  ///
    cout<<"Size of string is"<<sizeof(str)<<endl;
    cout<<str<<endl;
    cout<<str1;
    cout<<sizeof(str1)<<endl;
    cout<<strlen(str1)<<endl;


}
    