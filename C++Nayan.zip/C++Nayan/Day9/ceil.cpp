#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    float x=7.2;
    float y=5.9;
    float z=7.6;
    cout<<"Final value of ceil is\n"<<ceil(x)<<endl;
    cout<<"Final value floor is\n"<<floor(y)<<endl;
    cout<<"Final value round is\n"<<round(z)<<endl;
}