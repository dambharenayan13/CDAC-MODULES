#include<iostream>
#include<math.h>
using namespace std;
int main(){
    int val1,val2,val3;

    val1=abs(5);
    val2=abs(-13.5);
    val3=abs(3.87);
    int val4 = sqrt(64);

    cout<<val1<<endl;
    cout<<val2<<endl;
    cout<<val3<<"\n";
    cout<<"spuare root is"<<val4<<endl;
    return 0;

}