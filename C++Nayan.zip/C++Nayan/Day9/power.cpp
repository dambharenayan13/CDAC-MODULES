#include<iostream>
#include<math.h>
using namespace std;
int main(){
    int base=8;
    int exponential=2;
    int power=pow(base,exponential);

    cout<<"Power Is "<<power;
    return 0;
}  