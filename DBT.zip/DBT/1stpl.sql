drop procedure if exists pro1;
delimiter $
create procedure pro1()
BEGIN
	select "Hello World " R1;
end $
delimiter ;

drop procedure if exists pro1;
delimiter $
create procedure pro1()
BEGIN 
select*from dept;
end$ 
delimiter ;

drop procedure if exists pro1;
delimiter $ 
create procedure pro1()
BEGIN
insert into i values(1,1,1);
end$
delimiter ;


drop procedure if exists pro1;
delimiter $
create procedure pro1()
BEGIN
declare x int default 100;
declare y int ;
set y:=200;
select x+y;
end$
delimiter ;


drop procedure if exists pro1;
delimiter $
create procedure pro1(x int ,y int)
BEGIN
select x+y;
end$
delimiter ;

