package com.demo.array;

import java.util.Scanner;

public class Arrays {

	public static void main(String[] args) {
		int arr[]=new int [5];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter numbers");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		sum(arr);
		factorial(arr);
	

	}


	private static void sum(int[] arr) {
		int add=0;
		for(int i=0;i<arr.length;i++) {
			add=add+arr[i];
		}
		System.out.println("Additional of all array is "+add);
		
	}
	

	private static void factorial(int[] arr) {
		for(int num:arr)
		if(isPrime(num)) {
		int fact=1;
		for(int i=1;i<=num;i++) {
			fact=fact*i;
		}
		System.out.println("Factorial of prime"+num+"is"+fact);
	}
	}
	private static boolean isPrime(int n) {
		if(n<=1) {
			return false;
		}
		for(int i=2;i<n;i++) {
			if(n%i==0) {
				return false;
			}
		}
		return true;
	}
	
	

}
