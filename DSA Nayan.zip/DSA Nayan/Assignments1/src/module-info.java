/**
 * 
 */
/**
 * @author IET
 *
 */
module Assignments1 {
}