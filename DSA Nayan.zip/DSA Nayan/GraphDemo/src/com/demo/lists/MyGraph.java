package com.demo.lists;

public class MyGraph {
	MyLinkedList[] graph;
	
	public MyGraph(int v) {
		
	}

}
