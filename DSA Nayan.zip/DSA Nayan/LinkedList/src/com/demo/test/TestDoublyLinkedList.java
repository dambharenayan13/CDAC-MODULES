package com.demo.test;

import com.demo.linkedlist.DoublyLinkedList;

public class TestDoublyLinkedList {

	public static void main(String[] args) {
		DoublyLinkedList dlist=new DoublyLinkedList();
		dlist.addNode(20);
		dlist.displayData();
		dlist.addNode(30);
		dlist.displayData();
		dlist.addNode(45);
		dlist.displayData();
		dlist.addByPosition(3, 40);
		dlist.displayData();		
		dlist.addByValue(20,60 );
		dlist.displayData();
		dlist.deleteByPosition(3);
		dlist.displayData();
		dlist.deleteByvalue(60);
		dlist.displayData();
		

	}

}
