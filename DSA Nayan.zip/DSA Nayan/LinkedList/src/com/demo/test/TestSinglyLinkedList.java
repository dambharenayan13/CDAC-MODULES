package com.demo.test;

import com.demo.linkedlist.SinglyLinkedList;

public class TestSinglyLinkedList {

	public static void main(String[] args) {
		SinglyLinkedList list1=new SinglyLinkedList();
		list1.addNode(20);
		list1.addNode(10);
		list1.addNode(30);
		list1.addNode(15);
		list1.addNode(7);
		list1.displayData();
		list1.addByposition(1, 100);
		list1.addByposition(3, 300);
		list1.displayData();
		
		list1.deleteByValue(20);
		list1.displayData();
		list1.deleteBypos(5);
		list1.displayData();
	}

}
