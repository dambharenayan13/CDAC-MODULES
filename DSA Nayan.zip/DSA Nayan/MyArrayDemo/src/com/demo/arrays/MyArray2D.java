package com.demo.arrays;

import java.util.Arrays;
import java.util.Scanner;

public class MyArray2D {
	private int [] [] arr;
	public MyArray2D() {
		arr=new int [3][3];
	}
	public MyArray2D(int rows ,int columns) {
		arr=new int [rows][columns];
	}
	Scanner sc =new Scanner(System.in);
	public void acceptData() {
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				System.out.println("Enter the value "+i+","+j);
				arr[i][j]=sc.nextInt();
			}
		}
	}
	
	public void dislpayData() {
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
		System.out.println("-------------------------------");
	}
	
	public int[] findSumRowwise() {
		int []sumrows=new int [arr.length];
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				sumrows[i]+=arr[i][j];
			}
		}
		return sumrows;
	}
	
	public int[]findSumColumnwise(){
		int []sumcols=new int[arr[0].length];
		for(int i=0;i<arr[i].length;i++) {
			for(int j=0;j<arr.length;j++) {
				sumcols[i]+=arr[j][i];
			}
		}
		return sumcols;
		
	}
	
	public int [][] add2DArrays(MyArray2D ob){
		if(this.arr.length==ob.arr.length&&this.arr[0].length==ob.arr[0].length) {
			int [][]temp=new int [arr.length][arr[0].length] ;
			for(int i=0;i<arr.length;i++) {
				for(int j=0;j<arr[i].length;j++) {
					temp[i][j]=this.arr[i][j]+ob.arr[i][j];
				}
			}
			return temp;
		}
		return null;
	}
	
	public int [][] substract2DArrays(MyArray2D ob){
		if(this.arr.length==ob.arr.length&&this.arr[0].length==ob.arr[0].length) {
			int [][]temp=new int[arr.length][arr[0].length];
			for(int i=0;i<arr.length;i++) {
				for(int j=0;j<arr[i].length;j++) {
					temp[i][j]=this.arr[i][j]-ob.arr[i][j];
				}
			}
			return temp;
		}
		return null;
	}
	
	public void rowRotation(boolean flag,int num) {
		if(flag) {
			for(int cnt=0;cnt<num;cnt++) {
				int []temp=arr[0];
				for(int i=0;i<arr.length-1;i++) {
					arr[i]=arr[i+1];
				}
				arr[arr.length-1]=temp;
			}
		}
		else {
			for(int cnt=0;cnt<num;cnt++) {
				int []temp=arr[arr.length-1];
				for(int i=arr.length-1;i>0;i--) {
					arr[i]=arr[i-1];
				}
				arr[0]=temp;
			}
		}
	}
	
	public void columnRotation(boolean flag,int num) {
		if(flag) {
			for(int cnt=0;cnt<num;cnt++) {
				// to copy the last column into  temp array
				int []temp=new int [arr.length];
				for(int i=0;i<arr.length;i++) {
					temp[i]=arr[i][arr[0].length-1];
				}
				
				for(int i=0;i<arr.length;i++) {
					for(int j=arr[0].length-2;j>=0;j--) {
						arr[i][j+1]=arr[i][j];
					}
					}
				for(int i=0;i<arr.length;i++) {
					arr[i][0]=temp[i];
				}
			}
		}
		else {
			for(int cnt=0;cnt<num;cnt++) {
				int[]temp=new int[arr.length];
				for(int i=0;i<arr.length;i++) {
				temp[i]=arr[i][0];
			}
				
				for(int i=0;i<arr.length;i++) {
					for(int j=1;j<arr[0].length;j++) {
						arr[i][j-1]=arr[i][j];
					}
				}
					for(int i=0;i<arr.length;i++) {
						arr[i][arr[0].length-1]=temp[i];
					
				}
			}
		}
		
	}
	
	public int[][]transpose(){
		int [][]temp=new int [arr[0].length][arr.length];
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[0].length;j++) {
				temp[j][i]=arr[i][j];
			}
		}
		return  temp;
	}
	
	public boolean iSSymettric() {
		if(arr.length==arr[0].length) {
			for(int i=0;i<arr.length;i++) {
				for(int j=0;j<arr[0].length;j++ ) {
					if(arr[i][j]!=arr[j][i]);
					return false;
				}
			}
			return true;
		}
		return false;
	}
	
	public boolean isIdentity() {
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				if(i==j&&arr[i][j]!=1) {
					return false;
				}
				else if(i!=j&&arr[i][j]!=0) {
					return false;
				}
				
			}
		}
		return true;
	}
	
	

}
