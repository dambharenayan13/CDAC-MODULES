package com.demo.test;

import java.util.Arrays;

import com.demo.arrays.MyArray2D;

public class Test2DArray {

	public static void main(String[] args) {
		MyArray2D ob1=new MyArray2D();
		ob1.acceptData();
		ob1.dislpayData();
		
//	System.out.println(Arrays.toString(ob1.findSumRowwise()));
//	System.out.println(Arrays.toString(ob1.findSumColumnwise()));

		ob1.rowRotation(true, 1);
		ob1.dislpayData();
		ob1.rowRotation(false, 1);
		ob1.dislpayData();
		ob1.columnRotation(true, 2);
		ob1.columnRotation(false, 1);
		ob1.dislpayData();
		
//		int[][]arr=ob1.transpose();
//		displayArray(arr);
//		
		
		if(ob1.iSSymettric()) {
			System.out.println("Symmetric method");
		}
		else {
			System.out.println("not symmetric method");
		}
		
		if(ob1.isIdentity()) {
			System.out.println("Identity method");
		}
		else {
			System.out.println("Not Identity Method");
		}

	}
	
	private static void displayArray(int [][]arr) {
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[0].length;j++) {
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
	}

}
