package com.demo.test;

import java.util.stream.IntStream;

import com.demo.arrays.MyArray;

public class TestArray {

	public static void main(String[] args) {
	  MyArray ob=new MyArray();
	  System.out.println("capacity :"+ob.getCapacity());
	  ob.add(5);
	  ob.add(2);
	  ob.add(7);
	  System.out.println(ob);
	  ob.add(10, 2);
	  System.out.println(ob);
	  System.out.println("Position of 10:"+ob.searchByValue(10));
	  ob.add(3);
	  ob.add(4);
	  System.out.println(ob);
//	  ob.deleteByValue(7);
	  ob.add(1);
	  System.out.println(ob);
//      ob.deleteByPos(1);
//	  System.out.println(ob);
	  int [] arr1=ob.exchangeIndexValue();
//	  IntStream.of(arr1).forEach(e->System.out.println(e+","));
	  arr1=ob.reverseArray(true);
	  System.out.println(ob);
	  IntStream.of(arr1).forEach(e->System.out.println(e+","));
	  ob.rotatrArray(false, 3);
	  System.out.println(ob);

	  
	}

}
