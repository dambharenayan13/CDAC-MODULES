package com.demo.test;

import com.demo.trees.MyBinarySearchTree;

public class TestMyBinarySearchTree {

	public static void main(String[] args) {
		MyBinarySearchTree bst=new MyBinarySearchTree();
		bst.insertNode(31);
		bst.insertNode(15);
		bst.insertNode(17);
		bst.insertNode(18);
		bst.insertNode(10);
		bst.insertNode(40);
		bst.insertNode(32);
		bst.insertNode(45);
		bst.insertNode(33);
		System.out.println("Inorder");
		bst.inOrder();
		System.out.println("Preorder");
		bst.preOrder();
		System.out.println("Postorder");
		bst.postOrder();
		bst.search(33);
		bst.searchNonRecurrsive(31);
		bst.deleteNode(18);
		bst.inOrder();
		bst.deleteNode(32);
		bst.inOrder();
		bst.deleteNode(15);
		bst.inOrder();


	}

}
