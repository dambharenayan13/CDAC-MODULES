package com.demo.test;

import com.demo.stacks.CircularQueue;

public class TestCirculatQueue {

	public static void main(String[] args) {
		CircularQueue cqueue=new CircularQueue(5);
		cqueue.enQueue(15);
		cqueue.enQueue(13);
		cqueue.enQueue(25);
		cqueue.enQueue(27);
		cqueue.enQueue(18);
		System.out.println(cqueue.deQueue());

	}

}
