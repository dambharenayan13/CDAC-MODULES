package com.demo.test;

import com.demo.stacks.MyQueueList;

public class TestMyQueueList {
	
	public static void main(String[] args) {
	MyQueueList qlist=new MyQueueList();
	qlist.enQueue(10);;
	qlist.enQueue(16);
	qlist.enQueue(15);
	System.out.println("----------------------------->");
	System.out.println(qlist.deQueue());
	System.out.println(qlist.deQueue());
	
	
	}

}
