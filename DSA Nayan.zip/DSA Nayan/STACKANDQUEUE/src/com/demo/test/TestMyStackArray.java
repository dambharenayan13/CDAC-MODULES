package com.demo.test;

import com.demo.stacks.MyStackArray;

public class TestMyStackArray {

	public static void main(String[] args) {
		
		MyStackArray ob=new MyStackArray(5);
		ob.push(25);
		ob.push(21);
		ob.push(13);
		ob.push(27);
		ob.push(16);
		ob.push(3);
		ob.push(4);
		System.out.println("------------------------->");
		System.out.println(ob.pop());
		System.out.println(ob.pop());
		System.out.println(ob.pop());
		System.out.println(ob.pop());
		System.out.println(ob.pop());
		System.out.println(ob.pop());
		

	}

}
