package com.demo.test;

import com.demo.stacks.MyStackList;

public class TestMyStackList {

	public static void main(String[] args) {
		
		MyStackList slist=new MyStackList();
		
		slist.push(40);
		slist.push(14);
		slist.push(13);
		slist.push(7);
		System.out.println("------------------------------->");
		System.out.println(slist.pop());
		System.out.println(slist.pop());
		System.out.println(slist.pop());
		

	}

}
