/**
 * 
 */
/**
 * @author IET
 *
 */
module STACKANDQUEUE {
}