package com.demo.search;

public class SearchingService {
	public static int sequentialSearch(int []arr,int search) {
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==search) {
				return i;
			}
		}
		return -1;
		
	}
	public static int binarySearchNonRecurssion(int [] arr,int search) {
		int low=0;
		int high=arr.length-1;
		int cnt=0;
		while(low<=high) {
			int mid=(low+high)/2;
			cnt++;
			if(arr[mid]==search) {
				System.out.println("comparisions are:"+cnt);
				return mid;
			}
			if(search<arr[mid]) {
				high=mid-1;
			}
			else {
				low=mid+1;
			}
		}
		System.out.println("Comparisions are:"+cnt);
		return -1; 
	}
	
	public static int binarySearchRecurssion(int[]arr,int search,int low ,int high ) {
		System.out.println("binary search called"+low+"---"+high);
		int mid=0;		
		if(low<=high) {
			 mid=(low +high)/2;
			 if(arr[mid]==search) {
			return mid;
		}
		else if(search<arr[mid]) {
			return binarySearchRecurssion(arr,search,low,mid-1);
		}
		else {
			return binarySearchRecurssion(arr,search,low,mid+1);
		}
		}
		return -1;
	}

}
