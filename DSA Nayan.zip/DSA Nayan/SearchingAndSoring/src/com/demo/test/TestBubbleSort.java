package com.demo.test;

import java.util.stream.IntStream;

import com.demo.sorting.bubbleSort;

public class TestBubbleSort {

	public static void main(String[] args) {
		int arr[]= {25,4,2,8,29,7,6,9,1,3};
		
//		bubbleSort.bubblesort(arr);
		bubbleSort.bubblesortimproved(arr);
	bubbleSort.bubblesortdescending(arr);
		IntStream.of(arr).forEach(e->System.out.print(e+"\t"));

	}

}
