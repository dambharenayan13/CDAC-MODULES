package com.demo.test;

import java.util.Arrays;

import com.demo.sorting.CountingSortAlgorithm;

public class TestCountingSort {

	public static void main(String[] args) {
		int []arr= {5,3,7,2,5,9,5,4,3};
		int[]output=CountingSortAlgorithm.countingSortAscending(arr);
		System.out.println("Sorted data");
		System.out.println(Arrays.toString(output));

	}

}
