package com.demo.test;

import com.demo.sorting.InsertionSortAlgorithm;

public class TestInsertionSort {

	public static void main(String[] args) {
		int arr[]= {21,4,6,18,13,5,16,9,7,2};
		InsertionSortAlgorithm.insertionSortAscending(arr);
//     	InsertionSortAlgorithm.insertionSortDescending(arr);

	}

}
