package com.demo.test;

import com.demo.sorting.quickSortAlgorithm;

public class TestQuickSort {

	public static void main(String[] args) {
		int arr[]= {4,8,9,28,29,13,1,11,14,17,5};
		quickSortAlgorithm.quickSort(arr, 0, arr.length-1);

	}

}
