package com.demo.test;

import com.demo.sorting.SelectionSortAlgorithm;

public class TestSelectionSort {

	public static void main(String[] args) {
		int arr[]= {15,17,2,5,3,10,7,8};
		 
//		SelectionSortAlgorithm.SelectionSortAscending(arr);
		SelectionSortAlgorithm.SelectionSortDescending(arr);

	}

}
