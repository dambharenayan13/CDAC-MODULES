package com.demo.test;

import com.demo.search.SearchingService;

public class TestService {

	public static void main(String[] args) {
		int []arr= {10,20,45,74,45,16,23,13,25,27};
		
		int pos=SearchingService.sequentialSearch(arr, 74);
		if(pos!=-1) {
			System.out.println("Number found at Position "+pos);
		}
		else {
			System.out.println("Not found");
		}
		
		int arr1[]= {41,7,88,9,45,6,3,5,7,1,22,25};
		
		 pos=SearchingService.binarySearchNonRecurssion(arr1, 8);
		if(pos!=-1) {
			System.out.println("Number found at position"+pos);
		}
		else {
			System.out.println("Not found");
		}
		
		pos=SearchingService.binarySearchRecurssion(arr1, 10, 5, 7);
		if(pos!=-1) {
			System.out.println("Number found at postion"+pos);
		}
		else {
			System.out.println("Not Found");
		}

	}

}
